package com.cj.dvc_server;

import com.cj.dvc_server.websocket.WebSocketServer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DvcServerApplication {

    public static void main(String[] args) {
        SpringApplication springApplication = new SpringApplication(DvcServerApplication.class);
        ConfigurableApplicationContext configurableApplicationContext = springApplication.run(args);
        WebSocketServer.setApplicationContext(configurableApplicationContext);
    }

}
