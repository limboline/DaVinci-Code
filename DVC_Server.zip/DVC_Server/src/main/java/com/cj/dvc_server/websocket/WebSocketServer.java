package com.cj.dvc_server.websocket;

import com.alibaba.fastjson.JSON;
import com.cj.dvc_server.Pojo.Player;
import com.cj.dvc_server.Pojo.PlayerInGame;
import com.cj.dvc_server.Pojo.Room;
import com.cj.dvc_server.Service.RoomService;
import com.cj.dvc_server.Service.WebSocketSessionMapService;
import com.cj.dvc_server.utils.DVC_Server_Utils;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.*;

@Component
@ServerEndpoint("/{roomid}/{playername}")
public class WebSocketServer{

    private String name;
    private int roomid;

    private static ApplicationContext applicationContext;
    private RoomService roomService;
    private WebSocketSessionMapService sessionMap;

    @OnOpen
    public void onOpen(@PathParam("roomid") Integer roomid,
                       @PathParam("playername") String playername,
                       Session session) throws IOException{

        roomService = applicationContext.getBean(RoomService.class);
        sessionMap = applicationContext.getBean(WebSocketSessionMapService.class);
        sessionMap.put(playername, session);
        this.roomid = roomid;
        this.name = playername;
        Room roominfo = roomService.getRoomInfo(roomid);

        PlayerInGame playerIG = new PlayerInGame();
        playerIG.setPlayer_name(name);
        playerIG.setCards(new ArrayList<>());
        playerIG.setChoice("");
        playerIG.setFlag(new HashMap<>());
        playerIG.setPlayer_state(DVC_Server_Utils.Player_Alive);

        List<PlayerInGame> playerInGames = roominfo.getPlayers();
        playerInGames.add(0, playerIG);

        roomService.updateRoomInfo(roominfo);

        for(PlayerInGame player : playerInGames){
            String msg = JSON.toJSONString(roominfo);
            sendMessage(msg, sessionMap.get(player.getPlayer_name()));
        }
    }


//    action(, name, position, num, N)
    @OnMessage
    public void OnMessage(String msg) throws IOException{

        roomService = applicationContext.getBean(RoomService.class);
        String[] operation = msg.split(",");
        Room roominfo = roomService.getRoomInfo(roomid);
        if(operation.length == 1){
            switch (operation[0]){
//                相同消息
                case DVC_Server_Utils.Action_Ready:
                    List<Player> player_info_ready = roominfo.getPlayers_info();
                    if(set_ready(true, player_info_ready)){
                        roominfo.setRoomstate(DVC_Server_Utils.Game_Ready);
                    }else{
                        roominfo.setRoomstate(DVC_Server_Utils.Game_Unready);
                    }
                    for(PlayerInGame player : roominfo.getPlayers()){
                        String message = JSON.toJSONString(roominfo);
                        sendMessage(message, sessionMap.get(player.getPlayer_name()));
                    }
                    break;
//                相同消息
                case DVC_Server_Utils.Action_Cancel:
                    List<Player> player_info_cancel = roominfo.getPlayers_info();
                    if(set_ready(false, player_info_cancel)){
                        roominfo.setRoomstate(DVC_Server_Utils.Game_Ready);
                    }else{
                        roominfo.setRoomstate(DVC_Server_Utils.Game_Unready);
                    }
                    for(PlayerInGame player : roominfo.getPlayers()){
                        String message = JSON.toJSONString(roominfo);
                        sendMessage(message, sessionMap.get(player.getPlayer_name()));
                    }
                    break;

//                不同消息
                case DVC_Server_Utils.Action_ChooseBlack:
                    Integer C_num_B = choose_card(true, roominfo);
                    if(C_num_B == null){
                        roominfo.setErr_msg("无黑色牌了");
                    }
                    roominfo.setRoomstate(DVC_Server_Utils.Guess_Cards);
                    for(int i = 0;i < roominfo.getPlayers().size();i++){
                        String player_name = roominfo.getPlayers().get(i).getPlayer_name();
                        String message = JSON.toJSONString(conversion(roominfo, player_name, C_num_B));
                        sendMessage(message, sessionMap.get(player_name));
                    }
                    break;

//                不同消息
                case DVC_Server_Utils.Action_ChooseWhite:
                    Integer C_num_W = choose_card(false, roominfo);
                    if(C_num_W == null){
                        roominfo.setErr_msg("无白色牌了");
                    }
                    roominfo.setRoomstate(DVC_Server_Utils.Guess_Cards);
                    for(int i = 0;i < roominfo.getPlayers().size();i++){
                        String player_name = roominfo.getPlayers().get(i).getPlayer_name();
                        String message = JSON.toJSONString(conversion(roominfo, player_name, C_num_W));
                        sendMessage(message, sessionMap.get(player_name));
                    }
                    break;

//                不同消息
                case DVC_Server_Utils.Action_Goon:
                    roominfo.setRoomstate(DVC_Server_Utils.Guess_Cards);
                    roominfo.setErr_msg("");

                    for(int i = 0;i < roominfo.getPlayers().size();i++){
                        String player_name = roominfo.getPlayers().get(i).getPlayer_name();
                        String message = JSON.toJSONString(conversion(roominfo, player_name, null));
                        sendMessage(message, sessionMap.get(player_name));
                    }
                    break;
//                相同消息
                case DVC_Server_Utils.Action_Pass:
                    int index = 0;
                    for(int i = 0;i < roominfo.getPlayers_info().size();i++){
                        Player player = roominfo.getPlayers_info().get(i);
                        if(player.getPlayer_name().equals(roominfo.getTurns_name())){
                            index = (i + 1) % roominfo.getPlayers().size();
                            while (roominfo.getPlayers().get(index).getPlayer_state() == DVC_Server_Utils.Player_Dead){
                                index++;
                                index %= roominfo.getPlayers().size();
                            }
                            break;
                        }
                    }
                    roominfo.setTurns_name(roominfo.getPlayers_info().get(index).getPlayer_name());
                    roominfo.setRoomstate(DVC_Server_Utils.Achieve_Cards);

                    for(int i = 0;i < roominfo.getPlayers().size();i++){
                        String player_name = roominfo.getPlayers().get(i).getPlayer_name();
                        String message = JSON.toJSONString(conversion(roominfo, player_name, null));
                        sendMessage(message, sessionMap.get(player_name));
                    }
                    break;
                default:
                    break;
            }
        }else{
//            不同消息
            if(operation[0].equals(DVC_Server_Utils.Action_Start)){
                if(roomService.startchoose(roominfo, name, operation[1])){
                    roominfo.setRoomstate(DVC_Server_Utils.Game_Start);
                    init_game(roominfo);
                    roomService.setchoose(roominfo);
                    for(int i = 0;i < roominfo.getPlayers().size();i++){
                        String player_name = roominfo.getPlayers().get(i).getPlayer_name();
                        String message = JSON.toJSONString(conversion(roominfo, player_name, null));
                        sendMessage(message, sessionMap.get(player_name));
                    }
                }
//            不同消息
            }else if (operation[0].equals(DVC_Server_Utils.Action_Guess)){

                check(roominfo, operation[1], Integer.parseInt(operation[2]), Integer.parseInt(operation[3]), Integer.parseInt(operation[4]));
                roominfo.setRoomstate(DVC_Server_Utils.Response_Decision);
                for(int i = 0;i < roominfo.getPlayers().size();i++){
                    String player_name = roominfo.getPlayers().get(i).getPlayer_name();
                    String message = JSON.toJSONString(conversion(roominfo, player_name, null));
                    sendMessage(message, sessionMap.get(player_name));
                }

//                相同消息
            }else if(operation[0].equals(DVC_Server_Utils.Action_Achieve)){
                Room room_achieve = new Room();
                roominfo.setTurns_name((roominfo.getPlayers_info().get(0).getPlayer_name()));
                roominfo.setRoomstate(DVC_Server_Utils.Achieve_Cards);

                room_achieve.setTurns_name(roominfo.getPlayers_info().get(0).getPlayer_name());
                room_achieve.setRoomstate(DVC_Server_Utils.Achieve_Cards);
                room_achieve.setRest_black(new ArrayList<>(roominfo.getRest_black()));
                room_achieve.setRest_white(new ArrayList<>(roominfo.getRest_white()));
                List<PlayerInGame> players = new ArrayList<>();
                for(PlayerInGame player : roominfo.getPlayers()){
                    PlayerInGame p = new PlayerInGame();
                    p.setPlayer_name(player.getPlayer_name());
                    p.setPlayer_state(DVC_Server_Utils.Player_Alive);
                    players.add(p);
                }
                room_achieve.setPlayers(players);
                String message = JSON.toJSONString(room_achieve);
                sendMessage(message, sessionMap.get(operation[1]));
            }
        }
        roomService.updateRoomInfo(roominfo);


    }

    @OnClose
    public void Onclose() throws IOException{
        roomService = applicationContext.getBean(RoomService.class);
        roomService.deletePlayer(roomid, name);
        sessionMap.remove(name);
    }

    @OnError
    public void onErr(Session session, Throwable error){
        error.printStackTrace();
    }

    public void sendMessage(String msg, Session session) throws IOException{
        session.getBasicRemote().sendText(msg);
    }

//    是否全体准备好
    private boolean set_ready(boolean ready_cancel, List<Player> players){
        boolean is_ready = true;
        for(Player player : players){
            if(player.getPlayer_name().equals(name)){
                if(ready_cancel){
                    player.setState(DVC_Server_Utils.Player_Ready);
                }else{
                    player.setState(DVC_Server_Utils.Player_Unready);
                }
            }
            is_ready &= player.getState() == DVC_Server_Utils.Player_Ready;
        }

        return is_ready && players.size() > 1;
    }

//    是否还能取该颜色的牌
    private Integer choose_card(boolean black_white, Room roominfo){

        List<PlayerInGame> players;
        List<Integer> rest;

        if(black_white){
            players = roominfo.getPlayers();
            rest = roominfo.getRest_black();
        }else{
            players = roominfo.getPlayers();
            rest = roominfo.getRest_white();
        }
        if(rest.isEmpty()){
            return null;
        }

        int index = new Random().nextInt(rest.size());
        int card_num = rest.get(index);
        rest.remove(index);

        for(PlayerInGame player : players){
            if(player.getPlayer_name().equals(name)){
                if(black_white){
                    card_num = card_num * 2;
                    player.getCards().add(card_num);
                    player.getFlag().put(card_num, false);
                }else{
                    card_num = card_num * 2 + 1;
                    player.getFlag().put(card_num, false);
                    player.getCards().add(card_num);
                }
                player.getCards().sort(Comparator.comparingInt(o -> o));
            }
        }
        return card_num;
    }

//    初始化房间信息
    public void init_game(Room roominfo) {
        List<Integer> rest_white = roominfo.getRest_white();
        List<Integer> rest_black = roominfo.getRest_black();
        for(int i = 0;i < 13;i++){
            rest_white.add(i);
        }
        for(int i = 0;i < 13;i++){
            rest_black.add(i);
        }
    }

    public Room conversion(Room roominfo, String name, Integer C_num){
        Room R = new Room(roominfo);
        List<PlayerInGame> players = R.getPlayers();
        for (int i = 0;i < players.size();i++) {
            PlayerInGame player = players.get(i);
            player.getFlag().clear();
            if (!player.getPlayer_name().equals(name)) {
                List<Integer> cards = player.getCards();
                Map<Integer, Boolean> flag = roominfo.getPlayers().get(i).getFlag();
                for (int j = 0; j < cards.size(); j++) {
                    if (DVC_Server_Utils.is_black(cards.get(j))) {
                        if(!flag.get(cards.get(j))){

                            if(cards.get(j).equals(C_num)){
                                cards.set(j, DVC_Server_Utils.BBB_New);
                            }else {
                                cards.set(j, DVC_Server_Utils.BBB);
                            }
                        }
                    } else {
                        if(!flag.get(cards.get(j))){

                            if(cards.get(j).equals(C_num)){
                                cards.set(j, DVC_Server_Utils.WWW_New);
                            }else{
                                cards.set(j, DVC_Server_Utils.WWW);
                            }
                        }
                    }
                }
            }
        }
        if(R.getRoomstate() == DVC_Server_Utils.Guess_Cards && C_num != null){
            if(R.getTurns_name().equals(name)){
                R.setErr_msg(String.valueOf(C_num));
            }else{
                R.setErr_msg("");
            }
        }
        return R;
    }

    public void check(Room roominfo, String name, Integer position, Integer card_num, Integer guess_num){
        boolean is_right = false;
        PlayerInGame P = null;
        for(int i = 0;i < roominfo.getPlayers().size();i++){
            PlayerInGame player = roominfo.getPlayers().get(i);
            if(player.getPlayer_name().equals(name)){
                is_right = player.getCards().get(position) / 2 == card_num;
                P = player;
                break;
            }
        }
        if(is_right){
            P.getFlag().put(P.getCards().get(position), true);
            boolean is_publice = true;
            for(Map.Entry<Integer, Boolean> entry : P.getFlag().entrySet()){
                is_publice &= entry.getValue();
            }
            if(is_publice){
                P.setPlayer_state(DVC_Server_Utils.Player_Dead);
            }
            roominfo.setErr_msg("right");
        }else{
            for(int i = 0;i < roominfo.getPlayers().size();i++){
                if(roominfo.getPlayers().get(i).getPlayer_name().equals(this.name)){
                    P = roominfo.getPlayers().get(i);
                    break;
                }
            }
            if(guess_num > -1){
                P.getFlag().put(guess_num, true);
            }
            roominfo.setErr_msg("wrong");
        }

    }

    public static void setApplicationContext(ApplicationContext applicationContext){
        WebSocketServer.applicationContext = applicationContext;
    }

}
