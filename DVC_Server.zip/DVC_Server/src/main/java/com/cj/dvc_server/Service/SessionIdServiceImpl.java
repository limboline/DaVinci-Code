package com.cj.dvc_server.Service;

import com.cj.dvc_server.Dao.PlayerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class SessionIdServiceImpl implements SessionIdService {

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Autowired(required = false)
    private PlayerMapper playerMapper;


    @Override
    public boolean hasKey(String UUID) {
        return redisTemplate.hasKey(UUID);
    }

    @Override
    public String getPlayerId(String UUID) {
        if(hasKey(UUID)){
            Integer player_id = (Integer) redisTemplate.opsForValue().get(UUID);
            return playerMapper.getById(player_id).getPlayer_name();
        }else{
            return null;
        }
    }

    @Override
    public void setID(String UUID, String name, boolean is_limited){
        Integer playerID = playerMapper.getByName(name);
        if(is_limited){
            redisTemplate.opsForValue().set(UUID, playerID, 3, TimeUnit.SECONDS);
        }else{
            redisTemplate.opsForValue().set(UUID, playerID);
        }

    }

    @Override
    public void expire(String key, long time, TimeUnit unit) {
        redisTemplate.expire(key, time, unit);
    }

    @Override
    public void persist(String key){
        redisTemplate.persist(key);
    }
}
