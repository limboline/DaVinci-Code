package com.cj.dvc_server.Service;

import org.springframework.stereotype.Service;

import javax.websocket.Session;

@Service
public class WebSocketSessionMapServicImpl implements WebSocketSessionMapService {
    @Override
    public void put(String key, Session value) {
        SessionMap.put(key, value);
    }

    @Override
    public Session get(String key) {
        return SessionMap.get(key);
    }

    @Override
    public void remove(String key) {
        SessionMap.remove(key);
    }
}
