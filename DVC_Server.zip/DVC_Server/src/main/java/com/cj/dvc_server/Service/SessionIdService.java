package com.cj.dvc_server.Service;

import java.util.concurrent.TimeUnit;

public interface SessionIdService {
    boolean hasKey(String UUID);
    String getPlayerId(String UUID);
    void setID(String UUID, String name, boolean is_limited);
    void expire(String key, long time, TimeUnit unit);
    void persist(String key);
}
