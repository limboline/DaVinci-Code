package com.cj.dvc_server.Dao;

import com.cj.dvc_server.Pojo.PlayerInfo;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PlayerMapper {

    @Select("select * from player_info where player_id = #{id}")
    PlayerInfo getById(Integer id);

    @Select("select player_id from player_info where player_name = #{name}")
    Integer getByName(String name);

    @Insert("INSERT INTO player_info (player_name, player_password, LEVEL, rank, total_num, win_num, leave_num) VALUES (#{name}, #{password}, 0, 0, 0, 0, 0);")
    void InsertPlayer(String name, String password);

    @Insert("INSERT INTO friends (playerA_id, playerB_id) VALUES (#{PlayerA_id}, #{PlayerB_id})")
    void InsertFriends(int PlayerA_id, int PlayerB_id);

    @Select("select playerB_id from friends where playerA_id = #{id}")
    List<Integer> getfriends(int id);

    @Delete("DELETE FROM friends WHERE playerA_id = #{p1_id} AND playerB_id = #{p2_id}")
    void DeleteFriend(int p1_id, int p2_id);
}
