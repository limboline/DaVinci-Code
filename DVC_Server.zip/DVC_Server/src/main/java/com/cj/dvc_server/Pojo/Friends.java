package com.cj.dvc_server.Pojo;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class Friends implements Serializable {
    private int data_id;
    private int playerA_id;
    private int playerB_id;
}
