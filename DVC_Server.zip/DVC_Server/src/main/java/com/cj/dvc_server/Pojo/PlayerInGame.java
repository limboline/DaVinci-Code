package com.cj.dvc_server.Pojo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class PlayerInGame implements Serializable{
    private String player_name;
    private Integer player_state;
    private List<Integer> cards;
    private HashMap<Integer, Boolean> flag;
    private String choice;

    public PlayerInGame(PlayerInGame player){
        setPlayer_name(player.getPlayer_name());
        setPlayer_state(player.getPlayer_state());
        setCards(new ArrayList<>(player.getCards()));
        flag = new HashMap<>();
        flag.putAll(player.getFlag());
        setChoice(player.getChoice());
    }
}
