package com.cj.dvc_server.Service;

import com.cj.dvc_server.Dao.PlayerMapper;
import com.cj.dvc_server.Pojo.PlayerInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PlayerServiceImpl implements PlayerService {

    @Autowired(required = false)
    private PlayerMapper playerMapper;

    @Override
    public PlayerInfo getById(Integer id) {
        return playerMapper.getById(id);
    }

    @Override
    public Integer getIDByName(String name) {
        return playerMapper.getByName(name);
    }

    @Override
    public PlayerInfo getPlayerByName(String name) {
        Integer id = getIDByName(name);
        if(id == null){
            return null;
        }
        return playerMapper.getById(id);
    }

    @Override
    public void InsertPlayer(String name, String password) {
        playerMapper.InsertPlayer(name, password);
    }

    @Override
    public void InsertFriends(String name1, String name2) {
        int id1 = getIDByName(name1);
        int id2 = getIDByName(name2);
        playerMapper.InsertFriends(id1, id2);
    }

    @Override
    public List<PlayerInfo> getFriends(String name) {
        int id = getIDByName(name);
        List<Integer> list = playerMapper.getfriends(id);
        List<PlayerInfo> re = new ArrayList<>();
        for(int id_temp : list){
            re.add(playerMapper.getById(id_temp));
        }
        return re;
    }

    @Override
    public void DeleteFriend(String name1, String name2) {
        int id1 = getIDByName(name1);
        int id2 = getIDByName(name2);
        playerMapper.DeleteFriend(id1, id2);
        playerMapper.DeleteFriend(id2, id1);
    }
}
