package com.cj.dvc_server.Service;

import com.cj.dvc_server.Pojo.PlayerInfo;

import java.util.List;

public interface PlayerService {
    PlayerInfo getById(Integer id);
    Integer getIDByName(String name);
    PlayerInfo getPlayerByName(String name);
    void InsertPlayer(String name, String password);
    void InsertFriends(String name1, String name2);
    List<PlayerInfo> getFriends(String name);
    void DeleteFriend(String name1, String name2);
}
