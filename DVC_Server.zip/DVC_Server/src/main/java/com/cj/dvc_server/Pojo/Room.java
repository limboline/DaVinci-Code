package com.cj.dvc_server.Pojo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class Room implements Serializable {
    private Integer roomId;
    private Integer roomStyle;
    private List<Player> players_info;
    private String host_name;
    private List<Integer> rest_num;
    private Integer roomstate;
    private List<PlayerInGame> players;
    private String Turns_name;
    private List<Integer> rest_white;
    private List<Integer> rest_black;
    private String err_msg;

    public Room(Room room){
        setRoomId(room.getRoomId());
        setRoomStyle(room.getRoomStyle());
        setPlayers_info(new ArrayList<>(room.getPlayers_info()));
        setHost_name(room.getHost_name());
        setRest_num(new ArrayList<>(room.getRest_num()));
        setRoomstate(room.getRoomstate());
        setTurns_name(room.getTurns_name());
        setRest_white(new ArrayList<>(room.getRest_white()));
        setRest_black(new ArrayList<>(room.getRest_black()));
        setErr_msg(room.getErr_msg());

        List<PlayerInGame> players = new ArrayList<>();
        for(PlayerInGame p : room.getPlayers()){
            players.add(new PlayerInGame(p));
        }
        setPlayers(players);
    }
}
