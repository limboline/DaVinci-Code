package com.cj.dvc_server.utils;

import com.cj.dvc_server.Pojo.*;

import java.util.ArrayList;
import java.util.List;

public class DVC_Server_Utils {
    final static public int Max_gap_Matching = 50;
    final static public int Max_gap_Ranking = 20;

    final static public int Matching = 1;
    final static public int Ranking = 2;


    final static public int Player_OnLine = 1;
    final static public int Player_Offline = 2;
    final static public int Player_Unready = 3;
    final static public int Player_Ready = 4;
    final static public int Player_Start = 5;
    final static public int Player_Alive = 6;
    final static public int Player_Dead= 7;


    final static public int Game_Unready = 1;
    final static public int Game_Ready = 2;
    final static public int Game_Start = 3;
    final static public int Achieve_Cards = 4;
    final static public int Guess_Cards = 5;
    final static public int Response_Decision = 6;



    final static public String Action_Guess = "guess";
    final static public String Action_Pass = "pass";
    final static public String Action_Ready = "ready";
    final static public String Action_Cancel = "cancel";
    final static public String Action_Start = "start";
    final static public String Action_Achieve = "achieve";
    final static public String Action_Goon = "goon";
    final static public String Action_ChooseBlack = "chooseblack";
    final static public String Action_ChooseWhite = "choosewhite";


    final static public int BBB = 66;
    final static public int WWW = 77;
    final static public int BBB_New = 88;
    final static public int WWW_New = 99;


    public static Player PI2P(PlayerInfo playerInfo){
        Player PF = new Player();
        PF.setPlayer_name(playerInfo.getPlayer_name());
        PF.setLevel(playerInfo.getLevel());
        PF.setRank(playerInfo.getRank());
        PF.setLeave_num(playerInfo.getLeave_num());
        PF.setTotal_num(playerInfo.getTotal_num());
        PF.setWin_num(playerInfo.getWin_num());
//        设置朋友状态（在线，离线，为准备，准备，游戏中）
//        PF.setState(0);
        return PF;
    }

    static public boolean is_black(Integer card){
        return card % 2 == 0;
    }

    static public boolean is_white(Integer card){
        return card % 2 == 1;
    }
}
