package com.cj.dvc_server.Pojo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class PlayerInfo implements Serializable {
    private int player_id;
    private String player_name;
    private String player_password;
    private int level;
    private int rank;
    private int total_num;
    private int win_num;
    private int leave_num;
}
