package com.cj.dvc_server.Service;

import javax.websocket.Session;
import java.util.HashMap;
import java.util.Map;

public interface WebSocketSessionMapService {

    Map<String, Session> SessionMap = new HashMap<>();
    void put(String key, Session value);
    Session get(String key);
    void remove(String key);

}
