package com.cj.dvc_server.Controller;

import com.alibaba.fastjson.JSON;
import com.cj.dvc_server.Pojo.Room;
import com.cj.dvc_server.Service.RoomService;
import com.cj.dvc_server.utils.DVC_Server_Utils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;

@Controller
public class PlayController {

    @Autowired(required = false)
    private RoomService roomService;

    @Autowired
    public RedisTemplate<Object, Object> redisTemplate;


    @RequestMapping("/addMatching")
    public void AddMatching(HttpServletRequest request, HttpServletResponse response) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
        String name = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        Room roominfo = roomService.findroom(name, DVC_Server_Utils.Matching);
        outputStream.write(JSON.toJSONString(roominfo).getBytes());
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

    @RequestMapping("/addRanking")
    public void AddRanking(HttpServletRequest request, HttpServletResponse response) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
        String name = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        Room roominfo = roomService.findroom(name, DVC_Server_Utils.Ranking);
        outputStream.write(JSON.toJSONString(roominfo).getBytes());
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

    @RequestMapping("/addRoom")
    public void AddRoom(HttpServletRequest request, HttpServletResponse response) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
        String str = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        String[] data = str.split(",");
        String name = data[0];
        int roomid = Integer.parseInt(data[1]);

        Room roominfo = roomService.addroom(name, roomid);
        outputStream.write(JSON.toJSONString(roominfo).getBytes());
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

    @RequestMapping("/createRoom")
    public void CreateRoom(HttpServletRequest request, HttpServletResponse response) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
        String str = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        String[] data = str.split(",");
        String name = data[0];
        int roomstyle = Integer.parseInt(data[1]);

        Room roominfo = roomService.createroom(name, roomstyle);
        outputStream.write(JSON.toJSONString(roominfo).getBytes());
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

}
