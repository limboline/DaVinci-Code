package com.cj.dvc_server.Service;

import com.cj.dvc_server.Pojo.Room;

public interface RoomService {
    Room findroom(String name, int roomstyle);
    Room createroom(String name, int roomstyle);
    Room addroom(String name, int roomid, int roomstyle);
    Room addroom(String name, int roomid);

    Room getRoomInfo(int roomid);
    Room deletePlayer(int roomid, String name);
    void updateRoomInfo(Room room);
    Boolean startchoose(Room roominfo, String name, String choice);
    void setchoose(Room roominfo);
}
