package com.cj.dvc_server.Service;

import com.cj.dvc_server.Pojo.Player;
import com.cj.dvc_server.Pojo.PlayerInGame;
import com.cj.dvc_server.Pojo.PlayerInfo;
import com.cj.dvc_server.Pojo.Room;
import com.cj.dvc_server.utils.DVC_Server_Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Autowired(required = false)
    private PlayerService playerService;

    @Override
    public Room findroom(String name, int roomstyle) {

        PlayerInfo player = playerService.getPlayerByName(name);

        String S = "";
        Integer gap = null;
        switch (roomstyle) {
            case DVC_Server_Utils.Matching:
                S = "RoomMatch";
                gap = DVC_Server_Utils.Max_gap_Matching;
                break;
            case DVC_Server_Utils.Ranking:
                S = "RoomRank";
                gap = DVC_Server_Utils.Max_gap_Ranking;
                break;
        }


        List<Object> rooms_1 = new ArrayList<>(Objects.requireNonNull(redisTemplate.opsForZSet().range(
                S, player.getRank() - gap, player.getRank())));
        List<Object> rooms_2 = new ArrayList<>(Objects.requireNonNull(redisTemplate.opsForZSet().range(
                S, player.getRank(), player.getRank() + gap)));


        Integer room1_id = rooms_1.size() > 0 ? (Integer) rooms_1.get(rooms_1.size() - 1) : null;
        Integer room2_id = rooms_1.size() > 0 ? (Integer) rooms_2.get(0) : null;

        int room_id;
        if (room1_id == null && room2_id == null) {
            return createroom(name, roomstyle);
        } else if (room1_id == null) {
            room_id = room2_id;
        } else if (room2_id == null) {
            room_id = room1_id;
        } else {
            Double score_1 = redisTemplate.opsForZSet().score(S, room1_id);
            Double score_2 = redisTemplate.opsForZSet().score(S, room2_id);
            if (Math.abs(score_1 - player.getRank()) < Math.abs(score_2 - player.getRank())) {
                room_id = room1_id;
            } else {
                room_id = room2_id;
            }
        }

        return addroom(name, room_id, roomstyle);
    }

    @Override
    public Room createroom(String name, int roomstyle) {
        int roomid = 0;
        String S = "";
        Room roominfo = new Room();
        switch (roomstyle) {
            case DVC_Server_Utils.Matching:
                S = "RoomMatch";
                roominfo.setRoomStyle(DVC_Server_Utils.Matching);
                break;
            case DVC_Server_Utils.Ranking:
                S = "RoomRank";
                roominfo.setRoomStyle(DVC_Server_Utils.Ranking);
                break;
        }
        do {
            String uid = UUID.randomUUID().toString().replace("-", "");
            int len = uid.length();
            for (int i = 0; i < 6; i++) {
                roomid *= 10;
                roomid += uid.charAt(len - 1 - i) % 10;
            }
        } while (redisTemplate.opsForZSet().score(S, roomid) != null);


        List<Player> players = new ArrayList<>();
        Player player = DVC_Server_Utils.PI2P(playerService.getPlayerByName(name));
        player.setState(DVC_Server_Utils.Player_Unready);
        player.setSeat_num(0);
        players.add(player);


        roominfo.setRoomId(roomid);
        roominfo.setPlayers_info(players);
        roominfo.setHost_name(name);
        roominfo.setRest_num(new ArrayList<>(Arrays.asList(1, 2, 3)));
        roominfo.setRoomstate(DVC_Server_Utils.Game_Unready);
        roominfo.setPlayers(new ArrayList<>());
        roominfo.setRest_white(new ArrayList<>());
        roominfo.setRest_black(new ArrayList<>());
        roominfo.setErr_msg("");
        roominfo.setTurns_name("");



        redisTemplate.opsForValue().set(roomid, roominfo);
        redisTemplate.opsForZSet().add(S, roomid, player.getRank());
/**/
        return roominfo;
    }

    @Override
    public Room addroom(String name, int roomid, int roomstyle) {
        Room roominfo = (Room) redisTemplate.opsForValue().get(roomid);
        if (roominfo == null) {
            Room room = new Room();
            room.setErr_msg("房间不存在");
            return roominfo;
        }else if(roominfo.getPlayers().size() == 4){
            roominfo.setErr_msg("房间已满");
            return roominfo;
        }
        List<Player> players = roominfo.getPlayers_info();
        List<Integer> rest_num = roominfo.getRest_num();

        Player player = DVC_Server_Utils.PI2P(playerService.getPlayerByName(name));
        player.setState(DVC_Server_Utils.Player_Unready);
        player.setSeat_num(rest_num.get(0));
        players.add(0, player);

        rest_num.remove(0);


        int score = 0;
        for (Player player_te : players) {
            score += player_te.getRank();
        }
        score /= players.size();

        switch (roomstyle) {
            case DVC_Server_Utils.Matching:
                redisTemplate.opsForZSet().add("RoomMatch", roomid, score);
                break;
            case DVC_Server_Utils.Ranking:
                redisTemplate.opsForZSet().add("RoomRank", roomid, score);
                break;
        }

        redisTemplate.opsForValue().set(roomid, roominfo);

        return roominfo;
    }

    @Override
    public Room addroom(String name, int roomid) {
        if (redisTemplate.opsForZSet().score("RoomMatch", roomid) != null) {
            return addroom(name, roomid, DVC_Server_Utils.Matching);
        } else if (redisTemplate.opsForZSet().score("RoomRank", roomid) != null) {
            return addroom(name, roomid, DVC_Server_Utils.Ranking);
        } else {
            return null;
        }
    }

    @Override
    public Room getRoomInfo(int roomid) {
        return (Room) redisTemplate.opsForValue().get(roomid);
    }

    @Override
    public Room deletePlayer(int roomid, String name) {
        Room roominfo = getRoomInfo(roomid);
        Integer Score = 0;
        boolean is_ready = true;
        for(int i = 0;i < roominfo.getPlayers_info().size();i++){
            Player player = roominfo.getPlayers_info().get(i);
            if(player.getPlayer_name().equals(name)){
                roominfo.getRest_num().add(player.getSeat_num());
                roominfo.getPlayers_info().remove(player);
            }else{
                is_ready &= (player.getState() == DVC_Server_Utils.Player_Ready);
                Score += player.getRank();
            }
        }
        roominfo.getPlayers().removeIf(playerInGameInfo -> playerInGameInfo.getPlayer_name().equals(name));

        if(roominfo.getPlayers_info().isEmpty()){
            redisTemplate.delete(roomid);
            if(roominfo.getRoomStyle() == DVC_Server_Utils.Matching){
                redisTemplate.opsForZSet().remove("RoomMatch", roomid);
            }else if(roominfo.getRoomStyle() == DVC_Server_Utils.Ranking){
                redisTemplate.opsForZSet().remove("RoomRank", roomid);
            }
        }else{
            if(is_ready && roominfo.getPlayers_info().size() > 1){
                roominfo.setRoomstate(DVC_Server_Utils.Game_Start);
            }
            Score /= roominfo.getPlayers_info().size();
            redisTemplate.opsForValue().set(roomid, roominfo);
            if(roominfo.getRoomStyle() == DVC_Server_Utils.Matching){
                redisTemplate.opsForZSet().add("RoomMatch", roomid, Score);
            }else if(roominfo.getRoomStyle() == DVC_Server_Utils.Ranking){
                redisTemplate.opsForZSet().add("RoomRank", roomid, Score);
            }
        }

        return roominfo;
    }

    @Override
    public void updateRoomInfo(Room room) {
        redisTemplate.opsForValue().set(room.getRoomId(), room);
    }

    @Override
    public Boolean startchoose(Room roominfo, String name, String choice) {
        boolean result = true;
        for(int i = 0;i < roominfo.getPlayers().size();i++){
            PlayerInGame player = roominfo.getPlayers().get(i);
            if(player.getPlayer_name().equals(name)){
                player.setChoice(choice);
            }
            result &= (!player.getChoice().equals(""));
        }
        return result;
    }

    @Override
    public void setchoose(Room roominfo) {
        for(int i = 0;i < roominfo.getPlayers().size();i++){
            PlayerInGame player = roominfo.getPlayers().get(i);
            int black = player.getChoice().charAt(1) - '0';
            int white = player.getChoice().charAt(3) - '0';
            init_choose_card(roominfo, player, black, white);
        }
    }

    private void init_choose_card(Room roominfo, PlayerInGame player, int black_num, int white_num){
        List<Integer> cards = player.getCards();
        for(int i = 0;i < black_num;i++){
            List<Integer> list = roominfo.getRest_black();
            int index = new Random().nextInt(list.size());
            int card_num = 2*list.get(index);
            cards.add(card_num);
            player.getFlag().put(card_num, false);
            list.remove(index);
        }
        for(int i = 0;i < white_num;i++){
            List<Integer> list = roominfo.getRest_white();
            int index = new Random().nextInt(list.size());
            int card_num = 2*list.get(index) + 1;
            cards.add(card_num);
            player.getFlag().put(card_num,false);
            list.remove(index);
        }
        cards.sort(Comparator.comparingInt(o -> o));
    }

}
