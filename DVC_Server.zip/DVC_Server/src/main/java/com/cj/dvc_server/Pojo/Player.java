package com.cj.dvc_server.Pojo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.websocket.Session;
import java.io.Serializable;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class Player implements Serializable {
    private String player_name;
    private int level;
    private int rank;
    private int total_num;
    private int win_num;
    private int leave_num;
    private int state;
    private int seat_num;
}
