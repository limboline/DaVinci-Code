package com.cj.dvc_server.Controller;

import com.alibaba.fastjson.JSON;
import com.cj.dvc_server.Pojo.Player;
import com.cj.dvc_server.Pojo.PlayerInfo;
import com.cj.dvc_server.Service.PlayerService;
import com.cj.dvc_server.Service.SessionIdService;
import com.cj.dvc_server.utils.DVC_Server_Utils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Controller
public class LoginController {

    final public int OK = 1;
    final public int Name_Not_Existed = 2;
    final public int Password_Wrong = 3;
    final public int Name_Existed = 4;
    final public int Password_Not_Same = 5;
    final public int Not_Found = 2;

    @Autowired
    private PlayerService playerService;
    @Autowired
    private SessionIdService sessionIdService;


    @RequestMapping("/login")
    public void Login(HttpServletRequest request, HttpServletResponse response) throws IOException {
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        String data = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());

        String[] S = data.split(",");
        String name = S[0];
        String password = S[1];
        String uuid = S[2];

        PlayerInfo playerInfo = playerService.getPlayerByName(name);
        if(playerInfo == null){
            outputStream.write(Name_Not_Existed);
        }else{
            if(playerInfo.getPlayer_password().equals(password)){
                outputStream.write((OK + "," + name).getBytes());
                sessionIdService.setID(uuid, name, false);
            }else{
                outputStream.write((OK + "," + name).getBytes());
            }
        }
        outputStream.flush();
        inputStream.close();
        outputStream.close();
    }

    @RequestMapping("/register")
    public void Register(HttpServletRequest request, HttpServletResponse response) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        String data = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());

        String[] S = data.split(",");
        String name = S[0];
        String password = S[1];

        PlayerInfo playerInfo = playerService.getPlayerByName(name);
        if(playerInfo != null){
            outputStream.write(Name_Existed);
        }else{
            playerService.InsertPlayer(name, password);
            outputStream.write(OK);
        }
        outputStream.flush();
        inputStream.close();
        outputStream.close();
    }

    @RequestMapping("/reconnect")
    public void Reconnect(HttpServletRequest request, HttpServletResponse response) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        String uuid = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
//        查找redis，
        String name = sessionIdService.getPlayerId(uuid);
        if(name != null){
//            redis重新计时
            sessionIdService.persist(uuid);
            outputStream.write((OK + "," + name).getBytes());
        }else{
            outputStream.write((Not_Found + "," + name).getBytes());
        }
        outputStream.flush();
        inputStream.close();
        outputStream.close();
    }

    @RequestMapping("/onStop")
    @ResponseBody
    public void onStop(HttpServletRequest request) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        String uuid = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        String name = sessionIdService.getPlayerId(uuid);

        sessionIdService.expire(uuid, 30, TimeUnit.MINUTES);
        inputStream.close();
    }


    @RequestMapping("/getFriends")
    @ResponseBody
    public void GetFriends(HttpServletRequest request, HttpServletResponse response) throws IOException{
        InputStream inputStream = new BufferedInputStream(request.getInputStream());
        String name = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        List<PlayerInfo> list = playerService.getFriends(name);
        List<Player> LL = new ArrayList<>();
        for(PlayerInfo playerInfo : list){
            LL.add(DVC_Server_Utils.PI2P(playerInfo));
        }

        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
        String Json = (String) JSON.toJSONString(LL);
        outputStream.write(Json.getBytes());
        outputStream.flush();
        inputStream.close();
        outputStream.close();
    }



    @RequestMapping("/testadd")
    @ResponseBody
    public String TestAdd(){
        sessionIdService.setID("aaa", "limboline", false);
        return "Add OK";
    }

    @RequestMapping("testquery")
    @ResponseBody
    public String TestQuery(){
        return sessionIdService.getPlayerId("aaa");
    }

    @RequestMapping("testpersist")
    @ResponseBody
    public String TestPersist(){
        sessionIdService.persist("aaa");
        return "Persist OK";
    }

    @RequestMapping("testexpire")
    @ResponseBody
    public String  TestExpire(){
        sessionIdService.expire("aaa", 10, TimeUnit.SECONDS);
        return "Expire OK";
    }

}
