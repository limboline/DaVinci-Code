package com.cj.dvc_code.Pojo;

import java.io.Serializable;
import java.util.List;

public class Room implements Serializable {

    private Integer roomId;
    private Integer roomStyle;
    private List<Player> players_info;
    private String host_name;
    private List<Integer> rest_num;
    private Integer roomstate;
    private List<PlayerInGame> players;
    private String Turns_name;          // 相对于List<Player>的位置
    private List<Integer> rest_white;
    private List<Integer> rest_black;
    private String err_msg;

    @Override
    public String toString() {
        return "Room{" +
                "roomId=" + roomId +
                ", roomStyle=" + roomStyle +
                ", players_info=" + players_info +
                ", host_name='" + host_name + '\'' +
                ", rest_num=" + rest_num +
                ", roomstate=" + roomstate +
                ", players=" + players +
                ", Turns_name='" + Turns_name + '\'' +
                ", rest_white=" + rest_white +
                ", rest_black=" + rest_black +
                ", err_msg='" + err_msg + '\'' +
                '}';
    }

    public Room() {
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Integer getRoomStyle() {
        return roomStyle;
    }

    public void setRoomStyle(Integer roomStyle) {
        this.roomStyle = roomStyle;
    }

    public List<Player> getPlayers_info() {
        return players_info;
    }

    public void setPlayers_info(List<Player> players_info) {
        this.players_info = players_info;
    }

    public String getHost_name() {
        return host_name;
    }

    public void setHost_name(String host_name) {
        this.host_name = host_name;
    }

    public List<Integer> getRest_num() {
        return rest_num;
    }

    public void setRest_num(List<Integer> rest_num) {
        this.rest_num = rest_num;
    }

    public Integer getRoomstate() {
        return roomstate;
    }

    public void setRoomstate(Integer roomstate) {
        this.roomstate = roomstate;
    }

    public List<PlayerInGame> getPlayers() {
        return players;
    }

    public void setPlayers(List<PlayerInGame> players) {
        this.players = players;
    }

    public String getTurns_name() {
        return Turns_name;
    }

    public void setTurns_name(String turns_name) {
        Turns_name = turns_name;
    }

    public List<Integer> getRest_white() {
        return rest_white;
    }

    public void setRest_white(List<Integer> rest_white) {
        this.rest_white = rest_white;
    }

    public List<Integer> getRest_black() {
        return rest_black;
    }

    public void setRest_black(List<Integer> rest_black) {
        this.rest_black = rest_black;
    }

    public String getErr_msg() {
        return err_msg;
    }

    public void setErr_msg(String err_msg) {
        this.err_msg = err_msg;
    }

}
