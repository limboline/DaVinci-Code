package com.cj.dvc_code.play;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.R;
import com.cj.dvc_code.websocket.MyWebSocketClient;
import org.java_websocket.client.WebSocketClient;

public class FragmentDecision extends Fragment {
    private Button mBtnGoon, mBtnPass;
    private MyWebSocketClient client;

    public FragmentDecision(MyWebSocketClient client){
        this.client = client;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_decision, container, false);
        mBtnGoon = view.findViewById(R.id.btn_goon);
        mBtnPass = view.findViewById(R.id.btn_pass);

        mBtnGoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                client.send("goon");
            }
        });
        mBtnPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                client.send("pass");
            }
        });
        return view;
    }
}
