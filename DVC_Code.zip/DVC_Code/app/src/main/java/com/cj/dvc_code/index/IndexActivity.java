package com.cj.dvc_code.index;

import android.content.Intent;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.cj.dvc_code.homepage.GameActivity;
import com.cj.dvc_code.login.MainActivity;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class IndexActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

        new Thread(){
            @Override
            public void run() {
                Looper.prepare();
                super.run();
                OutputStream os = null;
                InputStream is = null;
                FileInputStream fi = null;
                try {
                    URL url = new URL(DVC_Code_Utils.GameAddress + "reconnect");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.connect();

                    File file = getFileStreamPath(DVC_Code_Utils.filename);

                    if(file != null && file.exists()){
                        fi = openFileInput(DVC_Code_Utils.filename);
                        os = httpURLConnection.getOutputStream();
                        String uuid = IOUtils.toString(fi);
                        os.write(uuid.getBytes());
                        is = httpURLConnection.getInputStream();
                        String[] data = IOUtils.toString(is).split(",");
                        if(Integer.parseInt(data[0]) == DVC_Code_Utils.OK){
                            Intent intent = new Intent(IndexActivity.this, GameActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("name", data[1]);
                            intent.putExtra("uuid", uuid);
                            startActivity(intent);
                        }else{
                            Intent intent = new Intent(IndexActivity.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }else{
                        Intent intent = new Intent(IndexActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if(is != null){
                            is.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        if(os != null){
                            os.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        if(fi != null){
                            fi.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Looper.loop();
            }
        }.start();
    }
}
