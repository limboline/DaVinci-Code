package com.cj.dvc_code.play;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.Pojo.Player;
import com.cj.dvc_code.Pojo.Room;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;
import com.cj.dvc_code.websocket.MyWebSocketClient;
import org.java_websocket.enums.ReadyState;

import java.util.List;

public class FragmentReady extends Fragment {

    private Button mBtnReady;
    private ImageView mIvReady;

    private Player player;
    private int position;
    private MyWebSocketClient client;
    private boolean is_myself;

    private boolean is_ready = false;

    public FragmentReady(Player player, int position, MyWebSocketClient client, boolean is_myself){
        this.player = player;
        this.position = position;
        this.client = client;
        this.is_myself = is_myself;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view;
        if(position % 2 == 0){
            view = inflater.inflate(R.layout.fragment_top_bottm_ready, container, false);
        }else{
            view = inflater.inflate(R.layout.fragment_left_right_ready, container, false);
        }
        mBtnReady = view.findViewById(R.id.btn_ready);
        mIvReady = view.findViewById(R.id.iv_ready);

        if(is_myself){
            if(player.getState() == DVC_Code_Utils.Player_Unready){
                mBtnReady.setText("准备");
                mIvReady.setImageResource(0);
                is_ready = false;
            }else if(player.getState() == DVC_Code_Utils.Player_Ready){
                mBtnReady.setText("取消");
                mIvReady.setImageResource(R.drawable.ic_checkbox);
                is_ready = true;
            }
            mBtnReady.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!is_ready){
                        mBtnReady.setText("取消");
                        mIvReady.setImageResource(R.drawable.ic_checkbox);
                        is_ready = true;
//                        while (!client.getReadyState().equals(ReadyState.OPEN));
                        client.send("ready");
                    }else{
                        mBtnReady.setText("准备");
                        mIvReady.setImageResource(0);
                        is_ready = false;
//                        while (!client.getReadyState().equals(ReadyState.OPEN));
                        client.send("cancel");
                    }
                }
            });
        }else{
            mBtnReady.setVisibility(View.INVISIBLE);
            if(player.getState() == DVC_Code_Utils.Player_Unready){
                mIvReady.setImageResource(0);
            }else if(player.getState() == DVC_Code_Utils.Player_Ready){
                mIvReady.setImageResource(R.drawable.ic_checkbox);
            }
        }
        return view;
    }



}
