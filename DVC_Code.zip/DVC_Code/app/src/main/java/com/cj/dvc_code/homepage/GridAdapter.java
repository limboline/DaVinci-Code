package com.cj.dvc_code.homepage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.cj.dvc_code.Pojo.Player;
import com.cj.dvc_code.R;

import java.util.List;

public class GridAdapter extends RecyclerView.Adapter<GridAdapter.LinearViewHolder> {

    private Context mContext;
    private OnItemClickListener mListener;
    private List<Player> friends;

    public GridAdapter(Context context, OnItemClickListener listener, List<Player> friends){
        this.mContext = context;
        this.mListener = listener;
        this.friends = friends;
    }

    @NonNull
    @Override
    public LinearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LinearViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_friends_list, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull LinearViewHolder holder, final int position) {
//        holder.mIvFriendIcon.setImageResource();
        holder.mTvFriendName.setText(friends.get(position).getPlayer_name());
        holder.mTvFriendName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onClick(position);
            }
        });

        holder.mIvFriendIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return friends.size();
    }

    static class LinearViewHolder extends RecyclerView.ViewHolder{

        private TextView mTvFriendName;
        private ImageView mIvFriendIcon;

        public LinearViewHolder(@NonNull View itemView) {
            super(itemView);
            mTvFriendName = itemView.findViewById(R.id.tv_friend_name);
            mIvFriendIcon = itemView.findViewById(R.id.iv_friend_icon);
        }
    }

    public interface OnItemClickListener{
        void onClick(int pos);
    }
}
