package com.cj.dvc_code.play;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;

public class FragmentInitChoose extends Fragment {
    private MyCallBack myCallBack;
    private Integer player_num;
    private ImageView mIvB3W0, mIvB2W1, mIvB1W2, mIvB0W3;
    private ImageView mIvB4W0, mIvB3W1, mIvB2W2, mIvB1W3, mIvB0W4;

    public FragmentInitChoose(Integer player_num){
        this.player_num = player_num;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view;
        Onclick onclick = new Onclick();
        if(player_num == 4){
            view = inflater.inflate(R.layout.fragment_first_choose_4, container, false);
            mIvB3W0 = view.findViewById(R.id.iv_choice_B3W0);
            mIvB2W1 = view.findViewById(R.id.iv_choice_B2W1);
            mIvB1W2 = view.findViewById(R.id.iv_choice_B1W2);
            mIvB0W3 = view.findViewById(R.id.iv_choice_B0W3);
            mIvB3W0.setOnClickListener(onclick);
            mIvB2W1.setOnClickListener(onclick);
            mIvB1W2.setOnClickListener(onclick);
            mIvB0W3.setOnClickListener(onclick);
        }else{
            view = inflater.inflate(R.layout.fragment_first_choose, container, false);
            mIvB4W0 = view.findViewById(R.id.iv_choice_B4W0);
            mIvB3W1 = view.findViewById(R.id.iv_choice_B3W1);
            mIvB2W2 = view.findViewById(R.id.iv_choice_B2W2);
            mIvB1W3 = view.findViewById(R.id.iv_choice_B1W3);
            mIvB0W4 = view.findViewById(R.id.iv_choice_B0W4);
            mIvB4W0.setOnClickListener(onclick);
            mIvB3W1.setOnClickListener(onclick);
            mIvB2W2.setOnClickListener(onclick);
            mIvB1W3.setOnClickListener(onclick);
            mIvB0W4.setOnClickListener(onclick);
        }
        return view;
    }

    class Onclick implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            setDisable();
            switch (v.getId()){
                case R.id.iv_choice_B4W0:
                    mIvB3W1.setAlpha(0.2f);
                    mIvB2W2.setAlpha(0.2f);
                    mIvB1W3.setAlpha(0.2f);
                    mIvB0W4.setAlpha(0.2f);
                    myCallBack.callback("B4W0");
                    break;
                case R.id.iv_choice_B3W1:
                    mIvB4W0.setAlpha(0.2f);
                    mIvB2W2.setAlpha(0.2f);
                    mIvB1W3.setAlpha(0.2f);
                    mIvB0W4.setAlpha(0.2f);
                    myCallBack.callback("B3W1");
                    break;
                case R.id.iv_choice_B2W2:
                    mIvB4W0.setAlpha(0.2f);
                    mIvB3W1.setAlpha(0.2f);
                    mIvB1W3.setAlpha(0.2f);
                    mIvB0W4.setAlpha(0.2f);
                    myCallBack.callback("B2W2");
                    break;
                case R.id.iv_choice_B1W3:
                    mIvB4W0.setAlpha(0.2f);
                    mIvB3W1.setAlpha(0.2f);
                    mIvB2W2.setAlpha(0.2f);
                    mIvB0W4.setAlpha(0.2f);
                    myCallBack.callback("B1W3");
                    break;
                case R.id.iv_choice_B0W4:
                    mIvB4W0.setAlpha(0.2f);
                    mIvB3W1.setAlpha(0.2f);
                    mIvB2W2.setAlpha(0.2f);
                    mIvB1W3.setAlpha(0.2f);
                    myCallBack.callback("B0W4");
                    break;
                case R.id.iv_choice_B3W0:
                    mIvB2W1.setAlpha(0.2f);
                    mIvB1W2.setAlpha(0.2f);
                    mIvB0W3.setAlpha(0.2f);
                    myCallBack.callback("B3W0");
                    break;
                case R.id.iv_choice_B2W1:
                    mIvB3W0.setAlpha(0.2f);
                    mIvB1W2.setAlpha(0.2f);
                    mIvB0W3.setAlpha(0.2f);
                    myCallBack.callback("B2W1");
                    break;
                case R.id.iv_choice_B1W2:
                    mIvB3W0.setAlpha(0.2f);
                    mIvB2W1.setAlpha(0.2f);
                    mIvB0W3.setAlpha(0.2f);
                    myCallBack.callback("B1W2");
                    break;
                case R.id.iv_choice_B0W3:
                    mIvB3W0.setAlpha(0.2f);
                    mIvB2W1.setAlpha(0.2f);
                    mIvB1W2.setAlpha(0.2f);
                    myCallBack.callback("B0W3");
                    break;
            }
        }
    }

    public void setDisable(){
        if(player_num == 4){
            mIvB3W0.setEnabled(false);
            mIvB2W1.setEnabled(false);
            mIvB1W2.setEnabled(false);
            mIvB0W3.setEnabled(false);
        }else{
            mIvB4W0.setEnabled(false);
            mIvB3W1.setEnabled(false);
            mIvB2W2.setEnabled(false);
            mIvB1W3.setEnabled(false);
            mIvB0W4.setEnabled(false);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        myCallBack = (MyCallBack) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        myCallBack = null;
    }

    public interface MyCallBack{
        void callback(String choice);
    }
}
