package com.cj.dvc_code.play;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.Pojo.PlayerInGame;
import com.cj.dvc_code.Pojo.Room;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;

import java.util.List;

public class FragmentGuess extends Fragment {

    private Room roominfo;
    private Integer color;
    private Button[] mBtn = new Button[13];
    private MyCallBack myCallBack;

    public FragmentGuess(Integer color, Room room){
        this.roominfo = room;
        this.color = color;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_after_choose, container, false);
        init(view);
        return view;
    }

    class MyOnclick implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btn_0:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(0);
                    break;
                case R.id.btn_1:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(1);
                    break;
                case R.id.btn_2:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(2);
                    break;
                case R.id.btn_3:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(3);
                    break;
                case R.id.btn_4:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(4);
                    break;
                case R.id.btn_5:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(5);
                    break;
                case R.id.btn_6:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(6);
                    break;
                case R.id.btn_7:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(7);
                    break;
                case R.id.btn_8:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(8);
                    break;
                case R.id.btn_9:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(9);
                    break;
                case R.id.btn_10:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(10);
                    break;
                case R.id.btn_11:
                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(11);
                    break;
                case R.id.btn_underline:

                    for(Button btn : mBtn){
                        btn.setEnabled(false);
                        btn.setAlpha(0.2f);
                    }
                    myCallBack.callback_choose(12);
                    break;
            }
        }
    }

    private void init(View view){
        mBtn[0] = view.findViewById(R.id.btn_0);
        mBtn[1] = view.findViewById(R.id.btn_1);
        mBtn[2] = view.findViewById(R.id.btn_2);
        mBtn[3] = view.findViewById(R.id.btn_3);
        mBtn[4] = view.findViewById(R.id.btn_4);
        mBtn[5] = view.findViewById(R.id.btn_5);
        mBtn[6] = view.findViewById(R.id.btn_6);
        mBtn[7] = view.findViewById(R.id.btn_7);
        mBtn[8] = view.findViewById(R.id.btn_8);
        mBtn[9] = view.findViewById(R.id.btn_9);
        mBtn[10] = view.findViewById(R.id.btn_10);
        mBtn[11] = view.findViewById(R.id.btn_11);
        mBtn[12] = view.findViewById(R.id.btn_underline);

        if(color == DVC_Code_Utils.BBB){
            for(Button btn : mBtn){
                btn.setEnabled(true);
                btn.setAlpha(1.0f);
                btn.setTextColor(Color.parseColor("#ffffff"));
                btn.setBackgroundColor(Color.parseColor("#000000"));
            }
        }else{
            for(Button btn : mBtn){
                btn.setEnabled(true);
                btn.setAlpha(1.0f);
                btn.setTextColor(Color.parseColor("#000000"));
                btn.setBackgroundColor(Color.parseColor("#ffffff"));
            }
        }

        for(int i = 0;i < roominfo.getPlayers_info().size();i++){
            PlayerInGame player = roominfo.getPlayers().get(i);
            for(Integer card : player.getCards()){
                if(color == DVC_Code_Utils.BBB && card % 2 == 0 && card < 30){
                    mBtn[card/2].setAlpha(0.2f);
                    mBtn[card/2].setEnabled(false);
                }else if(color == DVC_Code_Utils.WWW && card % 2 == 1 && card < 30){
                    mBtn[card/2].setAlpha(0.2f);
                    mBtn[card/2].setEnabled(false);
                }
            }
        }

        MyOnclick myOnclick = new MyOnclick();
        for(Button btn : mBtn){
            btn.setOnClickListener(myOnclick);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        myCallBack = (MyCallBack) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        myCallBack = null;
    }

    public interface MyCallBack{
        void callback_choose(int card);
    }
}
