package com.cj.dvc_code.Pojo;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlayerInGame implements Serializable {
    private String player_name;
    private Integer player_state;
    private List<Integer> cards;
    private Map<Integer, Boolean> flag = new HashMap<>();
    private String choice;

    @Override
    public String toString() {
        return "PlayerInGame{" +
                "player_name='" + player_name + '\'' +
                ", player_state=" + player_state +
                ", cards=" + cards +
                ", flag=" + flag +
                ", choice='" + choice + '\'' +
                '}';
    }

    public Integer getPlayer_state() {
        return player_state;
    }

    public void setPlayer_state(Integer player_state) {
        this.player_state = player_state;
    }

    public String getPlayer_name() {
        return player_name;
    }

    public void setPlayer_name(String player_name) {
        this.player_name = player_name;
    }

    public List<Integer> getCards() {
        return cards;
    }

    public void setCards(List<Integer> cards) {
        this.cards = cards;
    }

    public Map<Integer, Boolean> getFlag() {
        return flag;
    }

    public void setFlag(Map<Integer, Boolean> flag) {
        this.flag = flag;
    }

    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }

    public PlayerInGame() {
    }
}
