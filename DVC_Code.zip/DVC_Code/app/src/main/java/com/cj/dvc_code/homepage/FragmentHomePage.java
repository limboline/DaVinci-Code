package com.cj.dvc_code.homepage;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.play.PlayActivity;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class FragmentHomePage extends Fragment {



    Button mBtnAddMatching, mBtnAddRanking, mBtnAddRoom, mBtnCreateRoom;

    private String name;
    private int yourChoice = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_homepage, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);

        Bundle bundle = getArguments();
        name = bundle.getString("name");

//        访问http://192.168.0.108:8080/addMatching
//        请求参数name，返回参数roominfo（JSON格式，传递给PlayActivity）
        mBtnAddMatching.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        Looper.prepare();
                        super.run();

                        InputStream is = null;
                        OutputStream os = null;
                        try {
                            URL url = new URL(DVC_Code_Utils.GameAddress + "addMatching");
                            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                            httpURLConnection.setDoOutput(true);
                            httpURLConnection.connect();

                            os = httpURLConnection.getOutputStream();

                            os.write(name.getBytes());
                            os.flush();

                            is = httpURLConnection.getInputStream();
                            String Json = IOUtils.toString(is);

                            Intent intent = new Intent(getContext(), PlayActivity.class);
                            intent.putExtra("roominfo", Json);
                            intent.putExtra("name", name);
                            startActivity(intent);

                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                if(is != null){
                                    is.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            try {
                                if(os != null){
                                    os.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                        Looper.loop();
                    }
                }.start();
            }
        });


//        访问http://192.168.0.108:8080/addRanking
//        请求参数name，返回参数roominfo（JSON格式，传递给PlayActivity）
        mBtnAddRanking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        Looper.prepare();
                        super.run();

                        InputStream is = null;
                        OutputStream os = null;
                        try {
                            URL url = new URL(DVC_Code_Utils.GameAddress + "addRanking");
                            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                            httpURLConnection.setDoOutput(true);
                            httpURLConnection.connect();

                            os = httpURLConnection.getOutputStream();

                            os.write(name.getBytes());
                            os.flush();

                            is = httpURLConnection.getInputStream();
                            String Json = IOUtils.toString(is);

                            Intent intent = new Intent(getContext(), PlayActivity.class);
                            intent.putExtra("roominfo", Json);
                            intent.putExtra("name", name);
                            startActivity(intent);

                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                if(is != null){
                                    is.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            try {
                                if(os != null){
                                    os.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                        Looper.loop();
                    }
                }.start();
            }
        });

//        访问http://192.168.0.108:8080/addRoom
//        请求参数name + roomid，返回参数roominfo（JSON格式，传递给PlayActivity）
        mBtnAddRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                View V = LayoutInflater.from(getActivity()).inflate(R.layout.layout_dialog_addroom, null);
                final EditText roomId = V.findViewById(R.id.et_roomid);
//                Button mBtnConfirm = V.findViewById(R.id.btn_confirm);
//                Button mBtnCancel = V.findViewById(R.id.btn_cancel);
                builder.setView(V).setCancelable(false);
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        new Thread(){
                            @Override
                            public void run() {
                                Looper.prepare();
                                super.run();

                                InputStream is = null;
                                OutputStream os = null;
                                try {
                                    URL url = new URL(DVC_Code_Utils.GameAddress + "addRoom");
                                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                                    httpURLConnection.setDoOutput(true);
                                    httpURLConnection.connect();

                                    os = httpURLConnection.getOutputStream();

                                    os.write((name + "," + roomId.getText().toString()).getBytes());
                                    os.flush();

                                    is = httpURLConnection.getInputStream();
                                    String Json = IOUtils.toString(is);

                                    Intent intent = new Intent(getContext(), PlayActivity.class);
                                    intent.putExtra("roominfo", Json);
                                    intent.putExtra("name", name);
                                    startActivity(intent);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                } finally {
                                    try {
                                        if(is != null){
                                            is.close();
                                        }
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        if(os != null){
                                            os.close();
                                        }
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                Looper.loop();
                            }
                        }.start();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });

//        访问http://192.168.0.108:8080/addRoom
//        请求参数name + yourChoice，返回参数roominfo（JSON格式，传递给PlayActivity）
        mBtnCreateRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] items = {"匹配", "排位"};

                AlertDialog.Builder singleChoiceDialog = new AlertDialog.Builder(getActivity());
                singleChoiceDialog.setTitle("创建房间类型");
                singleChoiceDialog.setCancelable(false);
                // 第二个参数是默认选项，此处设置为0

                singleChoiceDialog.setSingleChoiceItems(items, 0,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                yourChoice = which;
                            }
                        });
                singleChoiceDialog.setPositiveButton("确定",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                new Thread(){
                                    @Override
                                    public void run() {
                                        Looper.prepare();
                                        super.run();

                                        InputStream is = null;
                                        OutputStream os = null;
                                        try {
                                            URL url = new URL(DVC_Code_Utils.GameAddress + "createRoom");
                                            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                                            httpURLConnection.setDoOutput(true);
                                            httpURLConnection.connect();

                                            os = httpURLConnection.getOutputStream();

                                            os.write((name + "," + yourChoice).getBytes());
                                            os.flush();

                                            is = httpURLConnection.getInputStream();
                                            String Json = IOUtils.toString(is);

                                            Intent intent = new Intent(getContext(), PlayActivity.class);
                                            intent.putExtra("roominfo", Json);
                                            intent.putExtra("name", name);
                                            startActivity(intent);

                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        } finally {
                                            try {
                                                if(is != null){
                                                    is.close();
                                                }
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                            try {
                                                if(os != null){
                                                    os.close();
                                                }
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                        }

                                        Looper.loop();
                                    }
                                }.start();
                            }
                        });
                singleChoiceDialog.setNegativeButton("取消",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                singleChoiceDialog.show();
            }
        });

    }


    private void init(View view) {
        mBtnAddMatching = view.findViewById(R.id.btn_add_matching);
        mBtnAddRanking = view.findViewById(R.id.btn_add_ranking);
        mBtnAddRoom = view.findViewById(R.id.btn_add_room);
        mBtnCreateRoom = view.findViewById(R.id.btn_create_room);
    }



}
