package com.cj.dvc_code.homepage;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alibaba.fastjson.JSON;
import com.cj.dvc_code.Pojo.Player;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class GameActivity extends AppCompatActivity {


    private TextView mTvHomePage, mTvRule, mTvNameMyself, mTvFriendsRequest;
    private ImageView mIvIconMyself;
    private EditText mEtFriendsName;
    private LinearLayout mLlFriendsRequest;
    private RecyclerView mRvFriendsList;
    private String name;
    private String uuid;

    private List<Player> friends = new ArrayList<>();

    private int flag = DVC_Code_Utils.HomePage_Choosed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        init();
        final FragmentHomePage fragmentHomePage = new FragmentHomePage();
        final FragmentRule fragmentRule = new FragmentRule();

        Bundle bundle = new Bundle();
        bundle.putString("name", name);
        fragmentHomePage.setArguments(bundle);

        getSupportFragmentManager().beginTransaction().add(R.id.fragment_homepage_rule, fragmentHomePage, "homepage").commitAllowingStateLoss();
        mTvHomePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag != DVC_Code_Utils.HomePage_Choosed){
                    flag = DVC_Code_Utils.HomePage_Choosed;

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_homepage_rule, fragmentHomePage, "homepage").commitAllowingStateLoss();
                    mTvHomePage.setTextColor(Color.parseColor("#000000"));
                    mTvRule.setTextColor(Color.parseColor("#DDDDDD"));
                }
            }
        });

        mTvRule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag != DVC_Code_Utils.Rule_Choosed){
                    flag = DVC_Code_Utils.Rule_Choosed;
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_homepage_rule, fragmentRule, "rule").commitAllowingStateLoss();
                    mTvHomePage.setTextColor(Color.parseColor("#DDDDDD"));
                    mTvRule.setTextColor(Color.parseColor("#000000"));
                }
            }
        });

        getFriends();

    }

    private void init(){
        mTvHomePage = findViewById(R.id.tv_homepage);
        mTvRule = findViewById(R.id.tv_rule);
        mTvNameMyself = findViewById(R.id.tv_name_myself);
        mTvFriendsRequest = findViewById(R.id.tv_friends_request);

        mIvIconMyself = findViewById(R.id.iv_icon_myself);
        mEtFriendsName = findViewById(R.id.et_player_name);
        mRvFriendsList = findViewById(R.id.rv_friendslist);
        mLlFriendsRequest = findViewById(R.id.ll_friends_request);

        name = getIntent().getStringExtra("name");
        uuid = getIntent().getStringExtra("uuid");

        mTvNameMyself.setText(name);
        mLlFriendsRequest.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0));

    }

    private Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    mRvFriendsList.setLayoutManager(new GridLayoutManager(GameActivity.this, 1));
                    mRvFriendsList.setAdapter(new GridAdapter(GameActivity.this, new GridAdapter.OnItemClickListener() {
                        @Override
                        public void onClick(int pos) {

                        }
                    }, friends));
                    break;
            }
        }
    };

    private void getFriends(){
        new Thread(){
            @Override
            public void run() {
                Looper.prepare();
                super.run();
                InputStream is = null;
                OutputStream os = null;
                try {
                    URL url = new URL(DVC_Code_Utils.GameAddress + "getFriends");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.connect();

                    os = httpURLConnection.getOutputStream();
                    os.write(name.getBytes());
                    os.flush();

                    is = httpURLConnection.getInputStream();
                    String Json = IOUtils.toString(is);
                    friends = JSON.parseArray(Json, Player.class);

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if(is != null){
                            is.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        if(os != null){
                            os.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Message msg = new Message();
                msg.what = 1;
                handler.sendMessage(msg);
                Looper.loop();
            }
        }.start();

    }


    @Override
    protected void onDestroy() {
        new Thread(){
            @Override
            public void run() {
                Looper.prepare();
                super.run();
                OutputStream os = null;
                InputStream is = null;
                try {
                    URL url = new URL(DVC_Code_Utils.GameAddress + "onStop");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.connect();

                    os = httpURLConnection.getOutputStream();
                    os.write(uuid.getBytes());
                    os.flush();

                    is = httpURLConnection.getInputStream();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if(os != null){
                            os.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        if(is != null){
                            is.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Looper.loop();
            }
        }.start();
        super.onDestroy();
    }
}


