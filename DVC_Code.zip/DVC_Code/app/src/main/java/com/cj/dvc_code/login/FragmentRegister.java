package com.cj.dvc_code.login;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;



public class FragmentRegister extends Fragment {


    private EditText mEtName, mEtPassword, mEtPasswordAgain, mEtVerification;
    private Button mBtnOK, mBtnCancel;
    private ImageView mIvVerification;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);

        mBtnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                注册验证
                final String name = mEtName.getText().toString();
                final String password = mEtPassword.getText().toString();
                final String password_again = mEtPasswordAgain.getText().toString();
                if (name.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("用户名不能为空").show();
                }else if (password.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("密码不能为空").show();
                }else if(password_again.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("请再输入一次密码").show();
                }else if(!password.equals(password_again)){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("两次密码不一致").show();
                }else{
                    new Thread(){
                        @Override
                        public void run() {
                            Looper.prepare();
                            super.run();
                            OutputStream os = null;
                            InputStream is = null;
                            try {
                                URL url = new URL(DVC_Code_Utils.GameAddress + "register");
                                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                                httpURLConnection.setDoOutput(true);
                                httpURLConnection.connect();

                                os = httpURLConnection.getOutputStream();
                                os.write((name + "," + password).getBytes());

                                is = httpURLConnection.getInputStream();
                                int StateCode = is.read();
                                switch (StateCode){
                                    case DVC_Code_Utils.OK:
//                                跳转主页
                                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                        builder.setMessage("注册成功").show();
                                        getFragmentManager().popBackStack();
                                        break;
                                    case DVC_Code_Utils.Name_Existed:
                                        AlertDialog.Builder builder1 = new AlertDialog.Builder(getContext());
                                        builder1.setMessage("用户名已存在").show();
                                        break;
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            } finally {
                                try {
                                    if(is != null){
                                        is.close();
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                try {
                                    if(os != null){
                                        os.close();
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            Looper.loop();
                        }
                    }.start();
                }
            }
        });

        mBtnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                注册取消，返回登录界面
                getFragmentManager().popBackStack();
            }
        });
    }

    void init(View view){
        mEtName = view.findViewById(R.id.et_name);
        mEtPassword = view.findViewById(R.id.et_password);
        mEtPasswordAgain = view.findViewById(R.id.et_password_again);
        mEtVerification = view.findViewById(R.id.et_verification_code);

        mBtnOK = view.findViewById(R.id.btn_OK);
        mBtnCancel = view.findViewById(R.id.btn_Cancel);

        mIvVerification = view.findViewById(R.id.iv_verification_code);
    }

}
