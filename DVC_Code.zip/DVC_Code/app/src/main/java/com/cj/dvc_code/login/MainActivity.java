package com.cj.dvc_code.login;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.cj.dvc_code.R;

public class MainActivity extends AppCompatActivity {

    FragmentLogin fragmentLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragmentLogin = new FragmentLogin();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_login_register, fragmentLogin, "login").commitAllowingStateLoss();

    }


}
