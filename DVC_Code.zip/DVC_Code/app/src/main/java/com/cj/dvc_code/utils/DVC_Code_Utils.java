package com.cj.dvc_code.utils;

import android.graphics.Color;
import android.widget.Button;

public class DVC_Code_Utils {
    final static public String GameAddress = "http://192.168.0.110:8080/";
    final static public String WSAddress = "ws://192.168.0.110:8080/";
    final static public String filename = "SessionId";

    final static public int OK = 1;
    final static public int Not_Found = 2;

    final static public int HomePage_Choosed = 1;
    final static public int Rule_Choosed = 2;

    final static public int Name_Not_Existed = 2;
    final static public int Password_Wrong = 3;
    final static public int Name_Existed = 4;
    final static public int Password_Not_Same = 5;

    final static public int Style_Match = 1;
    final static public int Style_Rank = 2;

    final static public int Game_Unready = 1;
    final static public int Game_Ready = 2;
    final static public int Game_Start = 3;
    final static public int Achieve_Cards = 4;
    final static public int Guess_Cards = 5;
    final static public int Response_Decision = 6;


    final static public int Player_OnLine = 1;
    final static public int Player_Offline = 2;
    final static public int Player_Unready = 3;
    final static public int Player_Ready = 4;
    final static public int Player_Start = 5;
    final static public int Player_Alive = 6;
    final static public int Player_Dead= 7;


    final static public int BBB = 66;
    final static public int WWW = 77;
    final static public int BBB_New = 88;
    final static public int WWW_New = 99;


    final static public int TextView_Width_Horizontal = 80;
    final static public int TextView_Height_Horizontal = 100;
    final static public int TextView_Width_Vertical = 40;
    final static public int TextView_Height_Vertical = 25;
    final static public int TextView_Size = 12;

    final static public int LEFT = 20;
    final static public int RIGHT = 20;
    final static public int TOP = 5;
    final static public int BOTTOM = 5;






    static public void SetButtonDisable(Button button){
        button.setEnabled(false);
        button.setTextColor(Color.parseColor("#CCCCCC"));
    }

    static public void SetButtonEnable(Button button){
        button.setEnabled(true);
        button.setTextColor(Color.parseColor("#000000"));
    }

    static public boolean is_black(Integer card){
        return card % 2 == 0 && card < 80;
    }

    static public boolean is_white(Integer card){
        return card % 2 == 1 && card < 80;
    }

}
