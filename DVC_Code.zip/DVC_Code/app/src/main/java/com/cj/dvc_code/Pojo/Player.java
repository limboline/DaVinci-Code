package com.cj.dvc_code.Pojo;

import java.io.Serializable;

public class Player implements Serializable {
    private String player_name;
    private Integer level;
    private Integer rake;
    private Integer total_num;
    private Integer win_num;
    private Integer leave_num;
    private Integer state;
    private Integer seat_num;

    @Override
    public String toString() {
        return "Player{" +
                "player_name='" + player_name + '\'' +
                ", level=" + level +
                ", rake=" + rake +
                ", total_num=" + total_num +
                ", win_num=" + win_num +
                ", leave_num=" + leave_num +
                ", state=" + state +
                ", seat_num=" + seat_num +
                '}';
    }

    public Integer getSeat_num() {
        return seat_num;
    }

    public void setSeat_num(Integer seat_num) {
        this.seat_num = seat_num;
    }

    public Player() {
    }

    public String getPlayer_name() {
        return player_name;
    }

    public void setPlayer_name(String player_name) {
        this.player_name = player_name;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getRake() {
        return rake;
    }

    public void setRake(Integer rake) {
        this.rake = rake;
    }

    public Integer getTotal_num() {
        return total_num;
    }

    public void setTotal_num(Integer total_num) {
        this.total_num = total_num;
    }

    public Integer getWin_num() {
        return win_num;
    }

    public void setWin_num(Integer win_num) {
        this.win_num = win_num;
    }

    public Integer getLeave_num() {
        return leave_num;
    }

    public void setLeave_num(Integer leave_num) {
        this.leave_num = leave_num;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}
