package com.cj.dvc_code.play;

import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.alibaba.fastjson.JSON;
import com.cj.dvc_code.FragmentEmpty;
import com.cj.dvc_code.FragmentEmpty_2;
import com.cj.dvc_code.FragmentLose;
import com.cj.dvc_code.Pojo.Player;
import com.cj.dvc_code.Pojo.PlayerInGame;
import com.cj.dvc_code.Pojo.Room;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;
import com.cj.dvc_code.websocket.MyWebSocketClient;

import java.net.URISyntaxException;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class PlayActivity extends AppCompatActivity implements FragmentInitChoose.MyCallBack, FragmentCard.MyCallBack, FragmentGuess.MyCallBack {


    private Button mBtnBlackChoose, mBtnWhiteChoose;
    private TextView mTvBlackRest, mTvWhiteRest, mTVRoomId;
    private ImageView mIvIcon0, mIvIcon1, mIvIcon2, mIvIcon3, mIvUndo;

    private Integer num;
    private Room roominfo;
    private String name;
    private String winner;

    private String guess_name;
    private Integer card_position;
    private Integer card_num;
    private Integer cur_num = -1;


    private MyWebSocketClient client;
    private static final long HEART_BEAT_RATE = 30 * 1000;//每隔10秒进行一次对长连接的心跳检测

    private Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 1) {
                update((Room) msg.obj);
            }else if(msg.what == 2){
                client.send("start," + msg.obj);
            }else if(msg.what == 3){
                client.send((String) msg.obj);
            }else if(msg.what == 4){
                client.send("guess," + msg.obj);
            }else if(msg.what == 5){
                finish();
            }
        }
    };

    private Runnable heartBeatRunnable = new Runnable() {
        @Override
        public void run() {
            if (client != null) {
                if (client.isClosed()) {
                    reconnectWs();
                }
            } else {
                //如果client已为空，重新初始化websocket
                try {
                    client = new MyWebSocketClient(
                            DVC_Code_Utils.WSAddress + roominfo.getRoomId() + "/" + name){
                        @Override
                        public void onMessage(String message) {
                            roominfo = JSON.parseObject(message, Room.class);
                            Message msg = new Message();
                            msg.what = 1;
                            msg.obj = roominfo;
                            handler.sendMessage(msg);
                        }
                    };
                    client.connect();
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
            }
            //定时对长连接进行心跳检测
            handler.postDelayed(this, HEART_BEAT_RATE);
        }
    };

    /**
     * 开启重连
     */
    private void reconnectWs() {
        handler.removeCallbacks(heartBeatRunnable);
        new Thread() {
            @Override
            public void run() {
                try {
                    //重连
                    client.reconnectBlocking();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        init();
        mIvUndo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_0, new FragmentEmpty()).commitAllowingStateLoss();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_1, new FragmentEmpty()).commitAllowingStateLoss();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_2, new FragmentEmpty()).commitAllowingStateLoss();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_3, new FragmentEmpty()).commitAllowingStateLoss();

        DVC_Code_Utils.SetButtonDisable(mBtnBlackChoose);
        DVC_Code_Utils.SetButtonDisable(mBtnWhiteChoose);
        mTVRoomId.setText("房间id:" + roominfo.getRoomId());

        try {
            client = new MyWebSocketClient(
                    DVC_Code_Utils.WSAddress + roominfo.getRoomId() + "/" + name){
                @Override
                public void onMessage(String message) {
                    roominfo = JSON.parseObject(message, Room.class);
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = roominfo;
                    handler.sendMessage(msg);
                }
            };
            client.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public void init(){
        mBtnBlackChoose = findViewById(R.id.btn_black_choose);
        mBtnWhiteChoose = findViewById(R.id.btn_white_choose);
        mIvUndo = findViewById(R.id.iv_undo);
        mTvBlackRest = findViewById(R.id.tv_rest_black_card);
        mTvWhiteRest = findViewById(R.id.tv_rest_white_card);
        mTVRoomId = findViewById(R.id.tv_roomid);

        mIvIcon0 = findViewById(R.id.iv_0);
        mIvIcon1 = findViewById(R.id.iv_1);
        mIvIcon2 = findViewById(R.id.iv_2);
        mIvIcon3 = findViewById(R.id.iv_3);

        name = getIntent().getStringExtra("name");
        String room_string = getIntent().getStringExtra("roominfo");
        roominfo = JSON.parseObject(room_string, Room.class);
        num = roominfo.getPlayers_info().get(0).getSeat_num();
    }



    public void update(Room roominfo){
        switch (roominfo.getRoomstate()){
            case DVC_Code_Utils.Game_Unready:
                UpdateBeforeStart(roominfo);
                break;
            case DVC_Code_Utils.Game_Ready:
                UpdateBeforeStart(roominfo);
                UpdateReady(roominfo);
                break;
            case DVC_Code_Utils.Game_Start:
                UpdateAfterStart(roominfo);
                client.send("achieve," + name);
                break;
            case DVC_Code_Utils.Achieve_Cards:
                UpdateBeforeAchieve(roominfo);
                break;
            case DVC_Code_Utils.Guess_Cards:
                UpdateBeforeGuess(roominfo);
                break;
            case DVC_Code_Utils.Response_Decision:
                UpdateBeforeDecision(roominfo);
                break;
        }

    }

    public void UpdateBeforeStart(Room roominfo){
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentEmpty()).commitAllowingStateLoss();
        boolean[] flag = new boolean[4];
        for(Player playerinfo : roominfo.getPlayers_info()){
            int I = (playerinfo.getSeat_num() + 4 - num) % 4;
            flag[I] = true;
            setPlayer(I, playerinfo);
        }
        for(int i = 0;i < 4;i++){
            if(!flag[i]){
                clearFragment(i, true);
            }
        }
    }

    public void UpdateReady(Room roominfo){
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentEmpty()).commitAllowingStateLoss();
        for(int i = 0;i < 4;i++){
            clearFragment(i, false);
        }
//        倒计时
/*
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
*/
//        选择初始化牌型
        choose_init(roominfo.getPlayers_info().size());
    }

    public void UpdateAfterStart(Room roominfo){
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentEmpty()).commitAllowingStateLoss();
        for(int i = 0;i < roominfo.getPlayers_info().size();i++){
            int I = (roominfo.getPlayers_info().get(i).getSeat_num() + 4 - num) % 4;
            setPlayerInGame(I, roominfo.getPlayers().get(i).getCards());
            mTvBlackRest.setText(String.valueOf(roominfo.getRest_black().size()));
            mTvWhiteRest.setText(String.valueOf(roominfo.getRest_white().size()));
        }
    }

    public void UpdateBeforeAchieve(final Room roominfo){
        if(check_alive_dead(roominfo)){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentEmpty()).commitAllowingStateLoss();
        }else{
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentLose()).commitAllowingStateLoss();
        }
        if(roominfo.getTurns_name().equals(name)){
            DVC_Code_Utils.SetButtonEnable(mBtnBlackChoose);
            DVC_Code_Utils.SetButtonEnable(mBtnWhiteChoose);
            mBtnBlackChoose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DVC_Code_Utils.SetButtonDisable(mBtnBlackChoose);
                    DVC_Code_Utils.SetButtonDisable(mBtnWhiteChoose);
                    mTvBlackRest.setText(String.valueOf(roominfo.getRest_black().size()));
                    Message msg = new Message();
                    msg.what = 3;
                    msg.obj = "chooseblack";
                    handler.sendMessage(msg);
                }
            });
            mBtnWhiteChoose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DVC_Code_Utils.SetButtonDisable(mBtnBlackChoose);
                    DVC_Code_Utils.SetButtonDisable(mBtnWhiteChoose);
                    mTvWhiteRest.setText(String.valueOf(roominfo.getRest_white().size()));
                    Message msg = new Message();
                    msg.what = 3;
                    msg.obj = "choosewhite";
                    handler.sendMessage(msg);
                }
            });
            if(roominfo.getRest_black().size() == 0){
                if(roominfo.getRest_white().size() == 0){
                    DVC_Code_Utils.SetButtonDisable(mBtnWhiteChoose);
                    DVC_Code_Utils.SetButtonDisable(mBtnBlackChoose);

                    cur_num = -1;
                    roominfo.setErr_msg("");
                    roominfo.setRoomstate(DVC_Code_Utils.Guess_Cards);
                    UpdateBeforeGuess(roominfo);

                }else{
                    DVC_Code_Utils.SetButtonDisable(mBtnBlackChoose);
                }
            }else{
                if(roominfo.getRest_white().size() == 0){
                    DVC_Code_Utils.SetButtonDisable(mBtnWhiteChoose);
                }
            }
        }
    }

    public void UpdateBeforeGuess(Room roominfo){
        if(check_alive_dead(roominfo)){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentEmpty()).commitAllowingStateLoss();
        }else{
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentLose()).commitAllowingStateLoss();
        }
        for(int i = 0;i < roominfo.getPlayers_info().size();i++){
            int I = (roominfo.getPlayers_info().get(i).getSeat_num() + 4 - num) % 4;
            if(I == 0 && !roominfo.getErr_msg().equals("")){
                cur_num = Integer.parseInt(roominfo.getErr_msg());
            }
            mTvBlackRest.setText(String.valueOf(roominfo.getRest_black().size()));
            mTvWhiteRest.setText(String.valueOf(roominfo.getRest_white().size()));
            setPlayerInGame(I, roominfo.getPlayers().get(i).getCards());
        }
    }

    public void UpdateBeforeDecision(Room roominfo){
        if(is_finish(roominfo.getPlayers())){
            AlertDialog.Builder dialog = new AlertDialog.Builder(PlayActivity.this);
            dialog.setTitle("游戏结束");
            dialog.setMessage(winner + "获胜了");
            dialog.setPositiveButton("返回主页", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Message message = new Message();
                    message.what = 5;
                    handler.sendMessage(message);
                }
            });
            dialog.show();
            return;
        }
        if(check_alive_dead(roominfo)){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentEmpty()).commitAllowingStateLoss();
        }else{
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentLose()).commitAllowingStateLoss();
        }
        for(int i = 0;i < roominfo.getPlayers_info().size();i++){
            int I = (roominfo.getPlayers_info().get(i).getSeat_num() + 4 - num) % 4;
            setPlayerInGame(I, roominfo.getPlayers().get(i).getCards());
        }
        if(roominfo.getTurns_name().equals(name)){
            if(roominfo.getErr_msg().equals("wrong")){
                client.send("pass");
            }else if(roominfo.getErr_msg().equals("right")){
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentDecision(client)).commitAllowingStateLoss();
            }
        }
    }



    public void clearFragment(int position, boolean has_icon){
        Integer fid = null;
        ImageView iv = null;
        switch (position){
            case 0:
                fid = R.id.fragment_0;
                iv = mIvIcon0;
                break;
            case 1:
                fid = R.id.fragment_1;
                iv = mIvIcon1;
                break;
            case 2:
                fid = R.id.fragment_2;
                iv = mIvIcon2;
                break;
            case 3:
                fid = R.id.fragment_3;
                iv = mIvIcon3;
                break;
        }
        getSupportFragmentManager().beginTransaction().replace(fid, new FragmentEmpty_2()).commitAllowingStateLoss();
        if (has_icon){
            iv.setImageResource(0);
        }
    }

    public void setPlayer(int position, Player player){
        Integer fid = null;
        ImageView iv = null;
        boolean is_myself = false;
        switch (position){
            case 0:
                fid = R.id.fragment_0;
                iv = mIvIcon0;
                is_myself = true;
                break;
            case 1:
                fid = R.id.fragment_1;
                iv = mIvIcon1;
                break;
            case 2:
                fid = R.id.fragment_2;
                iv = mIvIcon2;
                break;
            case 3:
                fid = R.id.fragment_3;
                iv = mIvIcon3;
                break;
        }
        iv.setImageResource(R.drawable.boy);
        getSupportFragmentManager().beginTransaction().replace(fid, new FragmentReady(player, position, client, is_myself)).commitAllowingStateLoss();
    }

    public void setPlayerInGame(int position, List<Integer> cards){
        Integer fid = null;
        switch (position){
            case 0:
                fid = R.id.fragment_0;
                break;
            case 1:
                fid = R.id.fragment_1;
                break;
            case 2:
                fid = R.id.fragment_2;
                break;
            case 3:
                fid = R.id.fragment_3;
                break;
        }
        getSupportFragmentManager().beginTransaction().replace(fid, new FragmentCard(position, cards)).commitAllowingStateLoss();
    }

    public void choose_init(Integer num){
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_choose, new FragmentInitChoose(num)).commitAllowingStateLoss();
    }

    public boolean check_alive_dead(Room roominfo){
        for(PlayerInGame player : roominfo.getPlayers()){
            if(player.getPlayer_name().equals(name)){
                if(player.getPlayer_state() == DVC_Code_Utils.Player_Alive){
                    return true;
                }else if(player.getPlayer_state() == DVC_Code_Utils.Player_Dead){
                    return false;
                }
            }
        }
        return true;
    }

    public boolean is_finish(List<PlayerInGame> players){
        String winner = "";
        for(PlayerInGame player : players){
            if(player.getPlayer_state() == DVC_Code_Utils.Player_Alive){
                if(winner.equals("")){
                    winner = player.getPlayer_name();
                }else{
                    return false;
                }
            }
        }
        this.winner = winner;
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        client.close();
    }

    @Override
    public void callback(String choice) {
        Message msg = new Message();
        msg.what = 2;
        msg.obj = choice;
        handler.sendMessage(msg);
    }

    @Override
    public void callback_guess(int position, int PPP) {
        if(roominfo.getRoomstate() == DVC_Code_Utils.Guess_Cards && roominfo.getTurns_name().equals(name)){
            Integer color = null;
            int p = (position + num) % 4;
            for(int i = 0;i < roominfo.getPlayers_info().size();i++){
                Player player = roominfo.getPlayers_info().get(i);
                if(player.getSeat_num() == p){
                    guess_name = player.getPlayer_name();
                    color = roominfo.getPlayers().get(i).getCards().get(PPP);
                }
            }
            card_position = PPP;

            FragmentGuess fragment = new FragmentGuess(color, roominfo);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_choose, fragment)
                    .commitAllowingStateLoss();
        }
    }

    @Override
    public void callback_choose(int card) {
        this.card_num = card;
        Message msg = new Message();
        msg.what = 4;
        msg.obj = guess_name + "," + card_position + "," + card_num + "," + cur_num;
        handler.sendMessage(msg);
    }
}
