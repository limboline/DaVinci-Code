package com.cj.dvc_code.play;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;

import java.util.List;

public class FragmentCard extends Fragment {
    private Integer position;
    private List<Integer> cards;

    private MyCallBack myCallBack;

    public FragmentCard(Integer position, List<Integer> cards){
        this.position = position;
        this.cards = cards;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view;
        int Width, Height;
        if(position % 2 == 0){
            view = inflater.inflate(R.layout.fragment_empty_horizontal, container, false);
            Width = DVC_Code_Utils.TextView_Width_Horizontal;
            Height = DVC_Code_Utils.TextView_Height_Horizontal;
        }else{
            view = inflater.inflate(R.layout.fragment_empty_vertical, container, false);
            Width = DVC_Code_Utils.TextView_Height_Vertical;
            Height = DVC_Code_Utils.TextView_Width_Vertical;
        }
        LinearLayout layout = view.findViewById(R.id.ll_cards);


        for (int i = 0;i < cards.size();i++) {
            Integer card = cards.get(i);
            TextView tv = new TextView(getContext());
            tv.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(Width, Height);
            params.setMargins(DVC_Code_Utils.LEFT, DVC_Code_Utils.TOP, DVC_Code_Utils.RIGHT, DVC_Code_Utils.BOTTOM);
            tv.setLayoutParams(params);
            tv.setTextSize(DVC_Code_Utils.TextView_Size);


            if (DVC_Code_Utils.is_black(card)) {
                tv.setBackgroundColor(Color.parseColor("#000000"));
                tv.setTextColor(Color.parseColor("#ffffff"));
                int card_N = card / 2;
                if (card_N >= 0 && card_N <= 11) {
                    tv.setText(String.valueOf(card_N));
                } else if (card_N == 12) {
                    tv.setText("-");
                }
            } else if(DVC_Code_Utils.is_white(card)){
                tv.setTextColor(Color.parseColor("#000000"));
                tv.setBackgroundColor(Color.parseColor("#ffffff"));
                int card_N = card / 2;
                if (card_N >= 0 && card_N <= 11) {
                    tv.setText(String.valueOf(card_N));
                } else if (card_N == 12) {
                    tv.setText("-");
                }
            } else if(card == DVC_Code_Utils.BBB_New){
                tv.setBackgroundColor(Color.parseColor("#666666"));
            } else if(card == DVC_Code_Utils.WWW_New){
                tv.setBackgroundColor(Color.parseColor("#DDDDDD"));
            }
            final int finalI = i;
            if(card == DVC_Code_Utils.BBB || card == DVC_Code_Utils.WWW){
                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myCallBack.callback_guess(position, finalI);
                    }
                });
            }

            layout.addView(tv);
        }
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        myCallBack = (MyCallBack) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        myCallBack = null;
    }

    public interface MyCallBack{
        void callback_guess(int position, int PPP);
    }
}
