package com.cj.dvc_code.login;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.cj.dvc_code.homepage.GameActivity;
import com.cj.dvc_code.R;
import com.cj.dvc_code.utils.DVC_Code_Utils;
import org.apache.commons.io.IOUtils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

public class FragmentLogin extends Fragment {


    private EditText mEtName, mEtPassword, mEtVerification;
    private Button mBtnLogin, mBtnRegister;
    private ImageView mIvVerification;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);

        mIvVerification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                生成验证码
            }
        });

        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                登陆验证
                final String name = mEtName.getText().toString();
                final String password = mEtPassword.getText().toString();
                if (name.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("用户名不能为空").show();
                }else if (password.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("密码不能为空").show();
                }else{

                    new Thread(){
                        @Override
                        public void run() {
                            Looper.prepare();
                            super.run();
                            OutputStream os = null;
                            InputStream is = null;
                            FileOutputStream fo = null;
                            try {
                                URL url = new URL(DVC_Code_Utils.GameAddress + "login");
                                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                                httpURLConnection.setDoOutput(true);
                                httpURLConnection.connect();

                                fo = getContext().openFileOutput(DVC_Code_Utils.filename, Context.MODE_PRIVATE);
                                String uuid = UUID.randomUUID().toString().replace("-", "");
                                fo.write(uuid.getBytes());

                                os = httpURLConnection.getOutputStream();
                                os.write((name + "," + password + "," + uuid).getBytes());

                                is = httpURLConnection.getInputStream();
                                String[] data = IOUtils.toString(is).split(",");
                                switch (Integer.parseInt(data[0])){
                                    case DVC_Code_Utils.OK:
//                                跳转主页
                                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                        builder.setMessage("登陆成功").show();
                                        Intent intent = new Intent(getContext(), GameActivity.class);
                                        intent.putExtra("name", data[1]);
                                        intent.putExtra("uuid", uuid);
                                        startActivity(intent);
                                        break;
                                    case DVC_Code_Utils.Name_Not_Existed:
                                        AlertDialog.Builder builder1 = new AlertDialog.Builder(getContext());
                                        builder1.setMessage("用户名不存在").show();
                                        break;
                                    case DVC_Code_Utils.Password_Wrong:
                                        AlertDialog.Builder builder2 = new AlertDialog.Builder(getContext());
                                        builder2.setMessage("密码错误").show();
                                        break;
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            } finally {
                                try {
                                    if(is != null){
                                        is.close();
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                try {
                                    if(os != null){
                                        os.close();
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                try {
                                    if(fo != null){
                                        fo.close();
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            Looper.loop();
                        }
                    }.start();

                }

            }
        });

        mBtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                跳转到fragment_resister
                Fragment fragment = getFragmentManager().findFragmentByTag("login");
                FragmentRegister fragmentRegister = new FragmentRegister();
                if(fragment != null){
                    getFragmentManager().beginTransaction().hide(fragment).add(R.id.fragment_login_register, fragmentRegister).addToBackStack(null).commitAllowingStateLoss();
                }else{
                    getFragmentManager().beginTransaction().replace(R.id.fragment_login_register, fragmentRegister).addToBackStack(null).commitAllowingStateLoss();
                }
            }
        });
    }

    void init(View view){
        mEtName = view.findViewById(R.id.et_name);
        mEtPassword = view.findViewById(R.id.et_password);
        mEtVerification = view.findViewById(R.id.et_verification_code);

        mBtnLogin = view.findViewById(R.id.btn_login);
        mBtnRegister = view.findViewById(R.id.btn_register);

        mIvVerification = view.findViewById(R.id.iv_verification_code);
    }




}
